package com.cryptops.bidding.cryptops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CryptopsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CryptopsApplication.class, args);
	}

}
